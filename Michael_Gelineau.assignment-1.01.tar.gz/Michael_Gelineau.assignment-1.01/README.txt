Project 1.01 terrain generation, created by Michael Gelineau

Generates a random 80x21 unit map with 2 regions of long grass, 1 region or more of water,
connecting paths going N-S E-W, with a PokeMart and PokeCenter along the path,
and random terrain such as boulders and trees.

WARNING: If it looks weird on your device, its probably because the terminal size is too small.
I recommend executing in command prompt with "Terrain_Generation.exe" after calling "make"

POTENTIAL BUG: 
Slight chance the paths will generate on the border of the map where the boulders should otherewise generate.
I believe I fixed it but in the case it does simply run again and it will be a fixed solution.