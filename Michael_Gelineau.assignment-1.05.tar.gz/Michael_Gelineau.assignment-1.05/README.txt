Michael Gelineau Project 1.05

HOW TO RUN: makefile should do it all.  Simply call make then ./poke327 and you should be good.

BUGS:  Registers when you try to attack an npc, you wont move and there will be a prompt above the map.  However cant move through once defeated.