Project_1.02 by Michael Gelineau

This one was a doosy.  I put in more time than I'd like to admit for what I have.  It kinda sorta works, I'll give additional info below.

HOW TO RUN:
    simply call make, then ./poke327.  It will ask you what you would like to do.  You can go any which direction and itll generate a new map and remember the previous map.
    For example: "What would you like to do" e <generate new map east with coords> "What would you like to do" w <pull up original map>.
    This also works with north and south.  Im sure youll understand once you play with it for a minute.

    When you try calling a direction multiple times and then try going back is when it messes up.  I have no idea what happens but it seems to only re-update the coordinates
    once you reach a map that has yet to be created yet.

Trying to learn this and Ocaml isnt fun.  Have a good day Mr or Ms grader!