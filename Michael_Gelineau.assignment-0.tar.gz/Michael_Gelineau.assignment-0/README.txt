Project0, the knights tour, created by Michael Gelineau.

Finds all possible knight tours on a 5x5 board as given by the size variable.  Not tested to work on other board sizes.
Each line contains all 25 locations on the board and are separated by commas as required.