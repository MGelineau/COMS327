Project 1.09 Michael Gelineau

HOW TO RUN: 'make clean all' is the safest route.  Then run './poke327'.  Performs as expected should be pretty self explanatory.  When using items from your bag hit q afterwards to exit.

POTENTIAL BUGS:  If the screen goes black when using an item from the bag (not in a pokemon battle, just when in the map) hit 'q' and it will bring you back to the map.