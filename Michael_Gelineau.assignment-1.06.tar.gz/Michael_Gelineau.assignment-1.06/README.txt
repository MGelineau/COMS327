Michael Gelineau Project_1.06

HOW TO RUN: 
Simply call make and it should generate all the necessary files.  Then call './poke327' to run.  Based on Sheaffer's 1.05 code so you can use arrow keys to move for ease.
Player can enter through any gate they please.  To fly, simply input 'f'.  It will then ask you where to go.  Your inputs will not be shown in the terminal but they are being registered.
To input just type in the X coord number you want, followed by a space, then your Y coord, then hit enter.

BUGS:  Your input will lag behind on the terminal when entering a gate.  The inputs are being registered, just not displayed immediately, keep going that direction another move or so
and it will display properly.