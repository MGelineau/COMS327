Project 1.03 by Michael Gelineau

HOW TO RUN:  simply call make, then ./poke327.  It will ask you what you would like to do because I just decided to keep that funcitonality implemented, just hit q.
It will then generate the maps for the shortest route to the player (marked with an '@').  It works for the most part, I couldn't quite figure out how to update the rest of the maps values.
That is why there are a bunch of spaces, otherwise it would all be MAX_INT.  It's pretty similar to the code Prof used for his path generation so I guess thats why they look similar.

Sometimes it generates paths that dont follow the paved roads, I know this is good but I couldn't figure out how to apply to all.

Have a good day :)