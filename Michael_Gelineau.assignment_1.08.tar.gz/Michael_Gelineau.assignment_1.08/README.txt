Project_1.08 Michael Gelineau

HOW TO RUN:  
make clean all, will clean any excess files and compile all necessary ones.  To run, call ./poke327.  You will be prompted to choose a Pokemon.
You can navigate through tall grass and have a 10% chance to encounter any pokemon (might want to do it slowly because theres a chance you'll skip past it).
Once encountering a Pokemon or an NPC you will be shown the pokemon you have chosen and the wild/trainer pokemon stats.  Press any key to continue.
The stats are reflected on what was discussed in the assignment.  The pokemon will get new moves as they level up.