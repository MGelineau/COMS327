Assignment_1.07 Michael Gelineau

HOW TO RUN: Runs as specified in hw specs.  Call 'make' then './poke327'.  You will then be prompted for which file you would like to view,
just put the file name, not the '.csv' at the end of it, if there is a typo or the file does not exist you will be told to retry.